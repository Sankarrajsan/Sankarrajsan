package com.sr.retrofitjwt

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sr.retrofitjwt.model.Post
import com.sr.retrofitjwt.repository.Repository
import kotlinx.coroutines.launch
import retrofit2.Response

class Mainviewmodel(val repository: Repository):ViewModel() {
    val myresponse:MutableLiveData<Response<Post>> =MutableLiveData()
    val myresponse2:MutableLiveData<Response<Post>> =MutableLiveData()
    val myresponse3:MutableLiveData<Response<List<Post>>> =MutableLiveData()
    fun getdata(){
        viewModelScope.launch {
            val response=repository.getdata()
            myresponse.value=response
        }
    }
    fun getdataperson(number:Int){
        viewModelScope.launch {
            val response=repository.getdataperson(number)
            myresponse2.value=response
        }
    }
    fun getdataall(id:Int,option: Map<String,String>){
        viewModelScope.launch {
            val response=repository.getdataall(id,option)
            myresponse3.value=response
        }
    }
    fun postdata(post: Post){
        viewModelScope.launch {
            val response=repository.postdata(post)
            myresponse.value=response
        }
    }
    fun postdata2(userId:Int,id:Int,title:String,body: String){
        viewModelScope.launch {
            val response=repository.postdata2(userId,id,title,body)
            myresponse.value=response
        }
    }
}