package com.sr.retrofitjwt.util

class Constants {
    companion object{
        const val Base_url="https://jsonplaceholder.typicode.com/"
    }
}