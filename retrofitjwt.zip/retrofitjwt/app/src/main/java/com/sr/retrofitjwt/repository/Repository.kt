package com.sr.retrofitjwt.repository

import androidx.lifecycle.viewModelScope
import com.sr.retrofitjwt.api.Retroinstance
import com.sr.retrofitjwt.model.Post
import kotlinx.coroutines.launch
import okhttp3.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST


class Repository {


//    @GET("posts/3")//path interface
//    suspend fun getdata(): retrofit2.Response<Post>

    //repository
 suspend fun getdata(): retrofit2.Response<Post>{
    return Retroinstance.apidata.getdata()
 }
    //viewmodel
//    fun getdata(){
//        viewModelScope.launch {
//            val response=repository.getdata(auth)
//            myresponse.value=response
//        }
//    }
//    suspend fun getdata(auth:String): retrofit2.Response<Post>{
//        return Retroinstance.apidata.getdata(auth)
//    }
    suspend fun getdataperson(number:Int):retrofit2.Response<Post>{
        return Retroinstance.apidata.getdataperson(number)
    }
    suspend fun getdataall(id:Int,option: Map<String,String>):retrofit2.Response<List<Post>>{
        return Retroinstance.apidata.getdataall(id,option)
    }

    suspend fun postdata( post:Post):retrofit2.Response<Post>{
        return Retroinstance.apidata.postdata(post)
    }
    suspend fun postdata2(userId:Int,id:Int,title:String,body: String):retrofit2.Response<Post>{
        return Retroinstance.apidata.postdata2(userId,id,title,body)
    }
}
