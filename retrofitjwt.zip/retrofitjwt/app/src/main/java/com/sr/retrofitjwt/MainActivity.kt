package com.sr.retrofitjwt

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.sr.retrofitjwt.model.Post
import com.sr.retrofitjwt.repository.Repository

class MainActivity : AppCompatActivity() {

     lateinit var textview:TextView
     lateinit var editText: EditText
     lateinit var button: Button
    private lateinit var viewModel: Mainviewmodel
    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textview=findViewById(R.id.textview)
        editText=findViewById(R.id.editTextid)
        button=findViewById(R.id.button)

        val repository=Repository()
        val viewModelFactory=Mainviewmodelfactory(repository)
        viewModel=ViewModelProvider(this,viewModelFactory).get(Mainviewmodel::class.java)


//val option:HashMap<String,String> = HashMap()
//        option.put("sort","id")
//        option.put("order","desc")
//        button.setOnClickListener {
//            val num=editText.text.toString()
            //val post=Post(1,78,"job_desc","android developer")
           // viewModel.postdata2(1,102,"jobposition","code developer")
        viewModel.getdata()
       // val post=Post("john","john@gmail.com","male","active")
        //viewModel.getdata("application/json")
            viewModel.myresponse.observe(this, Observer {response->
                if (response.isSuccessful) {
                    Log.d("res", response.body().toString())
                    Log.d("res", response.code().toString())
                 textview.text=response.body().toString()
                    Log.d("res", response.headers().toString())
                }
                else{
                    Log.d("res", response.errorBody().toString())
                    textview.text=response.code().toString()
                }
            })

    }
}