package com.sr.retrofitjwt.model

data class Post (val userid:Int,
                 val id:Int,
                 val title:String,
                 val body:String
                 )
//data class Post (val name:String,
//                 val email:String,
//                 val gender:String,
//                 val status:String
//)