package com.sr.retrofitjwt

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.sr.retrofitjwt.repository.Repository

class Mainviewmodelfactory(private val repository: Repository):ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return Mainviewmodel(repository) as T
    }
}