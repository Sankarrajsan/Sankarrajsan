package com.sr.retrofitjwt.api

import com.sr.retrofitjwt.util.Constants.Companion.Base_url
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class Retroinstance {


    companion object {
        private val client=OkHttpClient.Builder().apply {
            addInterceptor(Myinterceptor())
        }.build()

        private val retrofit by lazy {
            Retrofit.Builder()
                .baseUrl("https://jsonplaceholder.typicode.com")
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }

        val apidata: Simpleapi by lazy {
            retrofit.create(Simpleapi::class.java)
        }
    }
}