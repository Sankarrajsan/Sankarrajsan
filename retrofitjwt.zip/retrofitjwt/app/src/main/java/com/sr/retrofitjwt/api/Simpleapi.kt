package com.sr.retrofitjwt.api

import androidx.lifecycle.LiveData
import com.sr.retrofitjwt.model.Post
import okhttp3.Response
import retrofit2.http.*

interface Simpleapi {

    @GET("/posts/5")//path
    suspend fun getdata(): retrofit2.Response<Post>
    //suspend fun getdata(@Header("Auth")auth:String): retrofit2.Response<Post>

    @GET("posts/{postNumber}")//path
    suspend fun getdataperson(@Path("postNumber")number: Int): retrofit2.Response<Post>

    @GET("posts")//query
    suspend fun getdataall(@Query("userId") id: Int,
    @QueryMap option:Map<String,String> ): retrofit2.Response<List<Post>>

    @POST("posts")//postdata body type
//    @POST("/public/v2/users")
//    @Header("Accept")Accept: String,
//    @Header("Content-Type")Content_type: String,
//    @Header("Authorization")Authorization: String
    suspend fun postdata(@Body post:Post):retrofit2.Response<Post>

    @FormUrlEncoded//urel type data post
    @POST("posts")
    suspend fun postdata2(@Field ("userId")userId:Int,
    @Field("id") id:Int,
    @Field("title") title:String,
    @Field("body") body:String):retrofit2.Response<Post>
}