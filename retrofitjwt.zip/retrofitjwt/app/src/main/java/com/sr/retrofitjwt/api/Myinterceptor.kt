package com.sr.retrofitjwt.api

import android.annotation.SuppressLint
import okhttp3.Interceptor
import okhttp3.Response

class Myinterceptor:Interceptor {
    @SuppressLint("SuspiciousIndentation")
    override fun intercept(chain: Interceptor.Chain): Response {
        val request=chain.request()
            .newBuilder()
            .addHeader("Content-Type","application/json")
            .addHeader("X-Platform","Android")
            .addHeader("X-Auth-Token","123456789")
            .build()
            return chain.proceed(request)
    }
}